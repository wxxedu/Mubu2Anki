# Mubu2Anki

An Anki addon that turns your notes from Mubu to Anki flashcards. 
